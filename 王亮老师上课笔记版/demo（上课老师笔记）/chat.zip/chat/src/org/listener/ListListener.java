package org.listener;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.entity.UserBean;

@WebListener
public class ListListener implements ServletContextListener{

	@Override
	public void contextInitialized(ServletContextEvent event) {
		//����һ���û��б�
		List<UserBean> userList = new ArrayList<UserBean>();
		//���û��б����浽��������
		event.getServletContext().setAttribute("userList", userList);
		System.out.println("test=============================");
	}
	@Override
	public void contextDestroyed(ServletContextEvent event) {
		event.getServletContext().removeAttribute("userList");
	}
}
